﻿This is a simple converter application.
Using MVVM design partner, as the application grows we benefit from MVVM, unit testing.
Also, the benefits of separation of concerns.
Binding is a great advantage in MVVM, makinf the UI independent of the viewmodel and the model.
The implementation of a Converter is done by a apecific ViewModel that implements IConverter interface.